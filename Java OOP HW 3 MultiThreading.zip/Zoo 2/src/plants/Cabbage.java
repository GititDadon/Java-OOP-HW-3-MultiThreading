package plants;

import graphics.ZooFrame;
import graphics.ZooPanel;

/**
 * @author baroh
 *
 */
public class Cabbage extends Plant {
	
	
	public Cabbage(ZooFrame f,ZooPanel z) {
		super(f,z);
	}

}