package plants;

import graphics.ZooFrame;
import graphics.ZooPanel;

/**
 * @author baroh
 *
 */
public class Lettuce extends Plant {
	public Lettuce(ZooFrame f,ZooPanel z) {
		super(f,z);
	}
}